package com.example.tittle_tattle

data class News(
    val author: String,
    val title: String,
    val url: String,
    val imageUrl: String
)