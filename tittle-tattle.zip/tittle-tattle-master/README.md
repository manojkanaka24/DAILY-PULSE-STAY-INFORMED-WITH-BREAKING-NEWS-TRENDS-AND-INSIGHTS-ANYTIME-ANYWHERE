Android Project Coded By- Vedant.R.J.Chourey

Tittle-Tattle:

Stay updated with the latest news from around the world with this Android Kotlin news app.
This app uses the New API, a powerful and easy-to-use news aggregator service,
to fetch and display news articles from various sources and categories.
You can browse News panels through the application browsing feature and
you can search through different categories to find stories of your interest.

A Beginners Android Project.
